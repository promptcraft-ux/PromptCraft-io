# Fondamentaux de l'ingénierie du Prompting (2025)
[Historique du Prompt Engineering, Techniques modernes, Chain-of-Thought, ReAct, CoD, GraphRAG, avec illustrations]